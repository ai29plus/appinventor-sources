// Copyright 2010 Google Inc. All rights reserved.
package com.google.appengine.api.taskqueue;

/**
 * Queue name mismatch failure.
 *
 */
public class QueueNameMismatchException extends RuntimeException {
  private static final long serialVersionUID = 3220217839003207467L;

  public QueueNameMismatchException(String detail) {
    super(detail);
  }
}
